package com.dominiccaggese.daikichipathvariables;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaikichipathvariablesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaikichipathvariablesApplication.class, args);
	}

}
